<?php
$connect = mysqli_connect("localhost", "root", "123456", "farm");
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
	$query = "
	SELECT * FROM tbl_purchase_master 
	WHERE del_status LIKE '%".$search."%'

	";
}
else
{
	$query = "
	SELECT * FROM tbl_purchase_master ORDER BY pur_id";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
	$output .= '<div class="table-responsive">
					<table class="table table bordered">
						<tr>
							<th>VENDOR ID</th>
                            <th>NAME</th>
                            <th>COMPANY</th>
                            <th>STREET</th>
                            <th>CITY</th>
                            <th>DISTRICT</th>
                            <th>PHONE NUMBER</th>
                            <th>EMAIL</th>
                      
						</tr>';
	while($row = mysqli_fetch_array($result))
	{
		$output .= '
			<tr>
				<td>'.$row["pur_id"].'</td>
				<td>'.$row["vendor_name"].'</td>
				<td>'.$row["vendor_cmpny"].'</td>
				<td>'.$row["v_street"].'</td>
				<td>'.$row["v_city"].'</td>
                <td>'.$row["v_district"].'</td>
                 <td>'.$row["vendor_ph"].'</td>
                 <td>'.$row["vendor_email"].'</td>  
              
			</tr>
		';
	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>