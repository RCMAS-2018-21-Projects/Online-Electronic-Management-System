<?php include_once("../shares/db/mydatabase.inc");?>
 <?php include("top.php"); ?>
 <head>
<style> body
    {
         background:url(a.jpg) no-repeat top fixed ;
        background-size:cover;
        height: 1000px;
    }
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}

    </style>
 </head>




<link rel="stylesheet" href="file:///F|/css/print.css" type="text/css">
<script>
    function fun()
    { 
       var a=document.getElementById('a');
       a.style.visibility='hidden';
       window.print();
      
           }
	</script><br><br><br><br>
	<!--user--->
<img src="a.png" height="150" width="200" style="position:relative;top:20px;left:200px;">
<div style="position:relative;top:-90px;left:450px;"><b>BIG SHOP<br>
							Kakkanad,Ernakulam<br>
							682016<br>
							Telephone : +91 9020996500<br>
							Email : <a class="mail" href="mailto:mail@example.com">bigshop@gmail.com</a></b></div>

		<h1 style="position:relative;left:580px;top:-20px;color:blue"><u>BIG SHOP</u></h1>
		<br>
		<br>
		<br>
	<div class="checkout-right">
										<h1 style="position:relative;left:500px;top:30px;color:black;">STAFF INFORMATION</h1>

				<table border="1" style="position:relative;width:900px;left:190px;top:100px;">
					<thead>
						<tr>
							
							<th> Name</th>
							
							<th>Home Name</th>
                            	<th>City</th>
							
                            	<th>Pincode</th>
                            <th>Email</th>
							<th>phone No</th>
					
						
							
						</tr>
					</thead>
					<?php
					$sql="select * from tbl_staff";
					$tbl=getDatas($sql);
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr class="rem1">
						
						<td class="invert"><?php echo $tbl[$i][1];?></td>
						
						<td class="invert"><?php echo $tbl[$i][11];?></td>
						
						<td class="invert"><?php echo $tbl[$i][6];?></td>
						<td class="invert"><?php echo $tbl[$i][12];?></td>
					    <td class="invert"><?php echo $tbl[$i][10];?></td>
                        <td class="invert"><?php echo $tbl[$i][9];?></td>
               
						</tr>
					<?php 
					}
					?>
					</tbody>
				
				</table>
			</div>
	<!--user--><div style="position:relative;left:50px;top:10px">
<input type="submit" name="sub" id="a" value="Print" onclick="fun();" size="700"/>
</div>
