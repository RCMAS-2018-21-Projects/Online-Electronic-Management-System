<?php
include("top.php");
include_once("../shares/db/mydatabase.inc"); 

?>
<html>
<head>
<title>Staff report</title>
<style>
input[type=text]
{
border-radius:3px;
border-spacing: inherit;
height:50px;
background-color: rgba(216, 216, 216, 0.63);
width:500px;
color: black;
}
        .b{
        border-radius:3px;
        border-spacing: inherit;
        background-color: rgba(216, 216, 216, 0.63);
        width:500px;
    }  input[type=text]:hover{
    background-color: white;
    }
    

    }
input[type=submit],input[type=reset] {
    margin: auto;
    padding: 10px 25px;
    margin-top: 25px;
    background-color: #146eb4;
    color: white;
border:none;
outline:none;
    letter-spacing: 1px;
    outline: 0;
    cursor: pointer;
}
    label{
        color: white;
    }
    .box label input{
        display:none;
    }
    .box label span{
        position: relative;
        display: inline-block;
        margin: 20px 10px;
        width: 50px;
        font-size: 18px;
        background:rgba(216, 216, 216, 0.63);
        border: 1px solid #ccc;
        color:black;
        border-radius: 4px; 
            }
    .box label input:checked ~ span{
        color: red;
        border: 1px solid green;
    }
    .box label input:checked ~ span:before{
        content: '';
        width: 100%;
        height: 100%;
        position: absolute;
        top:0;
        left:0;
        background: green;
        z-index: -1;
        filter: blur(10px);
    }
    
    .btn{
           background-color: #146eb4; 
         height: 40px;
        width: 180px;
        
    }  
input[type=submit]:hover,button:hover
{
    background-color: #ff9900;
    color: white;
}
    .table1
{
	border-radius:3px;	
height:200px;
    padding: 9px;
    }
.container_1 {
    background-color:beige;
width: 710px;
    margin: auto;
    padding: 30px 30px 30px;
    box-sizing: border-box;
   -webkit-box-shadow: 0 0 40px #aaa;
    -moz-box-shadow: 0 0 40px #aaa;
    box-shadow: 0 0 40px #aaa;
    -webkit-transition: all 0.5s;
    -moz-transition: all 0.5s;
    transition: all 0.5s;
    -o-transition: all 0.5s;
    -ms-transition: all 0.5s;
    -webkit-box-shadow: 0px 1px 8px 0px rgba(158, 158, 158, 0.75);
    -moz-box-shadow: 0px 1px 8px 0px rgba(158, 158, 158, 0.75);
    box-shadow: 0px 1px 8px 0px rgba(158, 158, 158, 0.75);
    background: rgb(0, 0, 0); /* Fallback color */
    background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
    color:whitesmoke;
}
    h3{
        color: black;
    }   
    body{
        
        background-size:cover;
        height: 1800px;
        
    }
textarea
{
    width: 99%;
background-color: rgba(216, 216, 216, 0.63);
    border-radius: 4px;
    }

 th {
    background: rgba(0, 0, 0, 0.7); /* Black background with 0.5 opacity */
    color: orange;
    height: 40px;
}
    .td{
        background: rgba(0, 0, 0, 0.7); /* Black background with 0.5 opacity */
        color:whitesmoke;
        text-align: center;
        }
    @media print{
        #pbtn{
            display: none;
            
        }
    }   
</style><meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Search</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
    
    <link rel="stylesheet" href="file:///F|/css/print.css" type="text/css">
<script>
    function fun()
    { 
       var a=document.getElementById('a');
       a.style.visibility='hidden';
       window.print();
      
           }
    </script>
<?php
    
     date_default_timezone_set('Asia/Calcutta');
    $time = date('h:i', time());// current time
    $date=date('d-m-Y');
    ?>
   
</head>
<body>
    <h1><center>STAFF REPORTS</center></h1>
   <table   style="position: relative;left:360px;top:50px">
<tr>
                    
                    <td>
                        <label> 
                            <img src="a.png" width="350px;height:300px;" ><br>
					<h3><br>
                    North Kaloor,Ernakulam,<br>
                    Kerala<br>
					0484 240 2044<br>
                        <a href="mailto:info@example.com">info@bigshop.com</a></h3>
				</label>
                    
                    </td>
                  
                </tr>
           <tr><td></td></tr>
    </table>
 <div class="container">
		<br />
			<br />
			
			<div class="form-group">
				<div class="input-group">
					
				</div>
			</div>
			
			<div id="result"></div>
		</div>
		<div style="clear:both"></div>
		<br />
		
		//<br />
		//<br />
		//<br />


    		
	</body>
</html>


<script>
$(document).ready(function(){
	load_data();
	function load_data(query)
	{
		$.ajax({
			url:"fetchstaff.php",
			method:"post",
			data:{query:query},
			success:function(data)
			{
				$('#result').html(data);
			}
		});
	}
	
	$('#search_text').keyup(function(){
		var search = $(this).val();
		if(search != '')
		{
			load_data(search);
		}
		else
		{
			load_data();			
		}
	});
});
</script>
   <div style="position:relative;left:600px;top:150px;">
<input type="submit" name="sub" id="a" value="Print" onclick="fun();" size="800"/>
 <a href="index.PHP"> <input type="submit" name="sub" id="a" value="back" onclick="index.PHP" size="800"/></a>      
     </div>
                       
</body>
</html>
