<?php
include_once("../shares/db/mydatabase.inc");
 include("top.php");
?>
<head>
	<script type="text/javascript">
       history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
  history.pushState(null, document.title, location.href);
});
    </script>
<script src="maha.js"></script>
<style>
       
input,textarea,select,.ab{
                border: 2px solid;
             border-radius: 7px;
          
             
            }
            label,input[type=radio]{
                color: white;
                font-size: 20px;
            }
            table{
                padding-bottom:1em;
                width: 500px;
                height: 500px;
            }
            .div1 {
    border-radius: 5px;
    background-color: #f2f2f2;
    margin: auto;
   padding: 30px;
    width:50%;
}

input[type=submit],.ab {
    margin: auto;
    padding: 10px 25px;
    margin-top: 25px;
    background-color: #146eb4;
    color: white;
	border:none;
	outline:none;
    letter-spacing: 1px;
    outline: 0;
    cursor: pointer;
}
.heading h1 {
    font-weight: 600;
    letter-spacing: .5px;
    font-size: 40px;
    margin-bottom: .9em;
    text-align: center;
    color: deepskyblue;
    text-transform: uppercase;
    position: relative;
    margin-top: 0;
}
    body
    {
        background-image: url(viiew_stf.jpg);
        background-size: 1575px;
        background-repeat: no-repeat;
    }
input[type=submit]:hover,
{
	background-color: #ff9900;
    color: white;
}
.card{
 box-sizing: border-box;
        background: rgba(0,0,0,0.3);
  width:700px;
    height:750px;
    top: 100px;
  margin: auto;
  text-align:left;
  font-family: arial;
}
</style>
    <script src="maha.js"></script>
</head>
<?php
if(isset($_GET['id']))
{
    $id=$_GET['id'];
    $sql="select * from tbl_product where item_id='$id'";
    $tbl=getDatas($sql);
}?>

<div class="card">
<div class="w3_login">
<div class="heading"><br><br>
    <h1>EDIT PRODUCT</h1></div>

<form action="" method="POST" >
    
    <table   style="position: relative;left:100px;top:-20px;">
			<div id="err" style="color: red;height: 10px"></div>

                <tr>
                    <td>
                        <label> NAME</label>
                    </td>
                    <td>
                       <input type="text" name="staff_fname" value="<?php echo $tbl[0][1];?>" id="name" required> <p id="p0"></p>
                 <script>
                 $("#name").on("blur", function() {
    if ( $(this).val().match('^[a-zA-Z ]{3,50}$') ) {
       $('#p0').hide();
    } else {
         $('#p0').show();
       $('#p0').text("* please enter a valid  name *"); 
         $('#name').focus(); 
    }
  
});
    </script>  
                      </td>
                </tr>
            <script  src="css/jquery.js" type="text/javascript"></script>
     <script  src="css/jquery-ui.js" type="text/javascript"></script>
    <link href="css/jquery-ui.css"    rel="stylesheet" type="text/css">
           <tr><td></td></tr>
                 
                      <tr>
                    <td>
                        <label>Description</label>
                    </td>
                    <td>
                       <input type="text" name="staff_lname"  required="" value="<?php echo $tbl[0][5];?>" id="name1"> <p id="p11"></p>
                 <script>
                 $("#name1").on("blur", function() {
    if ( $(this).val().match('^[a-zA-Z ]{3,50}$') ) {
       $('#p11').hide();
    } else {
         $('#p11').show();
       $('#p11').text("* please enter a valid  name *"); 
         $('#name1').focus(); 
    }
  
});
    </script>  
                      </td>
                </tr>
                <tr><td></td></tr>
                 
                 
           <tr><td></td></tr> 
                
                
                <tr>
                    <td>
                        <label>Amount</label>
                    </td>
                    <td>
                       <input type="text" name="staff_street"  required="" value="<?php echo $tbl[0][7];?>" onkeypress="return verifyText(event,'err')"/>
                      </td>
                </tr>
           <tr><td></td></tr> 
                
                     
                
                
            </table>
            <br>
    <center><input type="submit" value="UPDATE"><br><br></center>
                    
    </form>  
            </div>
            
       
                                   </div>
    <?php           
		
    if(isset($_POST['staff_fname']))
        {
		$a=$_POST['staff_fname'];
        $b=$_POST['staff_lname'];
		$c=$_POST['staff_street'];
      
            
		$sql="update tbl_product set item_name='$a',item_dtls='$b',amnt='$c' where item_id='$id'";
		setDatas($sql);
		msgbox("updated");
            nextpage("view_pro.php");
        }
        
        ?>