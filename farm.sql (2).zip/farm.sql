-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 05, 2020 at 10:08 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `farm`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_brand`
-- 

CREATE TABLE `tbl_brand` (
  `brand_id` int(50) NOT NULL auto_increment,
  `brand_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`brand_id`),
  UNIQUE KEY `brand_name` (`brand_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

-- 
-- Dumping data for table `tbl_brand`
-- 

INSERT INTO `tbl_brand` VALUES (9, 'Apple');
INSERT INTO `tbl_brand` VALUES (15, 'Hitachi');
INSERT INTO `tbl_brand` VALUES (14, 'Oneplus');
INSERT INTO `tbl_brand` VALUES (12, 'Samsung ');
INSERT INTO `tbl_brand` VALUES (13, 'Bosch');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_cart`
-- 

CREATE TABLE `tbl_cart` (
  `cart_id` int(11) NOT NULL auto_increment,
  `buyer` varchar(50) NOT NULL,
  `p_id` int(11) NOT NULL,
  `p_name` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `num` int(11) NOT NULL,
  `t_amnt` int(11) NOT NULL,
  `img` varchar(50) NOT NULL,
  `pay_status` varchar(50) NOT NULL,
  `o_date` date NOT NULL,
  `place` varchar(50) NOT NULL,
  `del_status` varchar(50) NOT NULL,
  PRIMARY KEY  (`cart_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=282 ;

-- 
-- Dumping data for table `tbl_cart`
-- 

INSERT INTO `tbl_cart` VALUES (254, 'sweety@gmail.com', 14, 'Canon Power Shoot Sx 740', 'Canon', 2, 100000, '../uploads/a1.jpg', 'credit', '2020-11-27', 'ernakulam', 'DELIVERED');
INSERT INTO `tbl_cart` VALUES (258, 'fermina@gmail.com', 16, 'Bosch Front Load Washer', '.Bosch', 2, 80000, '../uploads/wachmach2.jpg', 'credit', '2020-11-28', '', 'PENDING');
INSERT INTO `tbl_cart` VALUES (257, 'sweety@gmail.com', 15, 'Samsung 65Q800T 8K QLED Television 65inch', 'Samsung ', 1, 10000, '../uploads/tv1.jpg', 'credit', '2020-11-28', 'ernakulam', 'PENDING');
INSERT INTO `tbl_cart` VALUES (259, 'fermina@gmail.com', 15, 'Samsung 65Q800T 8K QLED Television 65inch', 'Samsung ', 5, 50000, '../uploads/tv1.jpg', 'credit', '2020-11-28', '', 'PENDING');
INSERT INTO `tbl_cart` VALUES (261, 'fermina@gmail.com', 16, 'Bosch Front Load Washer', '.Bosch', 5, 200000, '../uploads/wachmach2.jpg', 'credit', '2020-11-28', '', 'DELIVERED');
INSERT INTO `tbl_cart` VALUES (269, 'au11@gmail.com', 18, 'New Apple iPhone 12 ', 'Apple', 1, 10000, '../uploads/phone.jpg', 'null', '0000-00-00', '', 'PENDING');
INSERT INTO `tbl_cart` VALUES (262, 'fermina@gmail.com', 16, 'Bosch Front Load Washer', 'Bosch', 1, 40000, '../uploads/wachmach2.jpg', 'null', '0000-00-00', '', 'PENDING');
INSERT INTO `tbl_cart` VALUES (263, 'admin@gmail.com', 16, 'Bosch Front Load Washer', '.Bosch', 1, 40000, '../uploads/wachmach2.jpg', 'credit', '2020-11-29', '', 'PENDING');
INSERT INTO `tbl_cart` VALUES (264, 'metty123@gmail.com', 15, 'Samsung 65Q800T 8K QLED Television 65inch', 'Samsung ', 1, 10000, '../uploads/tv1.jpg', 'credit', '2020-11-30', 'ernakulam', 'PENDING');
INSERT INTO `tbl_cart` VALUES (279, 'abin123@gmail.com', 18, 'New Apple iPhone 12 ', 'Apple', 1, 10000, '../uploads/phone.jpg', 'credit', '2020-12-03', 'ernakulam', 'PENDING');
INSERT INTO `tbl_cart` VALUES (280, 'abin123@gmail.com', 16, 'Bosch Front Load Washer', 'Bosch', 1, 40000, '../uploads/wachmach2.jpg', 'credit', '2020-12-03', 'ernakulam', 'PENDING');
INSERT INTO `tbl_cart` VALUES (281, 'abin123@gmail.com', 19, 'Oneplus 7T PRO Haze Blue', 'Oneplus', 1, 12000, '../uploads/6qq.jpg', 'credit', '2020-12-03', 'ernakulam', 'PENDING');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_category`
-- 

CREATE TABLE `tbl_category` (
  `cat_id` int(50) NOT NULL auto_increment,
  `cat_type` varchar(50) NOT NULL,
  PRIMARY KEY  (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- 
-- Dumping data for table `tbl_category`
-- 

INSERT INTO `tbl_category` VALUES (8, 'mobiles');
INSERT INTO `tbl_category` VALUES (10, 'tv');
INSERT INTO `tbl_category` VALUES (12, 'fridge');
INSERT INTO `tbl_category` VALUES (11, 'washing machine');
INSERT INTO `tbl_category` VALUES (13, 'laptop');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_customer`
-- 

CREATE TABLE `tbl_customer` (
  `ret_id` int(50) NOT NULL auto_increment,
  `ret_name` varchar(50) NOT NULL,
  `ret_dob` varchar(50) NOT NULL,
  `ret_street` varchar(50) NOT NULL,
  `ret_city` varchar(50) NOT NULL,
  `ret_district` varchar(50) NOT NULL,
  `ret_email` varchar(50) NOT NULL,
  `ret_ph` varchar(12) NOT NULL,
  `ret_house` varchar(55) NOT NULL,
  `ret_pincode` varchar(55) NOT NULL,
  PRIMARY KEY  (`ret_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- 
-- Dumping data for table `tbl_customer`
-- 

INSERT INTO `tbl_customer` VALUES (7, 'Anil', '01/10/1980', 'paravoor', 'kochin', 'ernakulam', 'anil@gmail.com', '9632587414', 'thaliath house', '683518');
INSERT INTO `tbl_customer` VALUES (8, 'Sweety', '01/01/1980', 'edapally road', 'kochi', 'ernakulam', 'sweety@gmail.com', '9632587414', 'puthussery house ', '683517');
INSERT INTO `tbl_customer` VALUES (9, 'Kiran Baby', '2020-11-05', 'varapuzha road', 'kochi', 'ernakulam', 'kkbaby123@gmail.com', '9879653450', 'Puthussery house puthenpally varapuzha', '683519');
INSERT INTO `tbl_customer` VALUES (10, 'abin', '2017-05-12', 'koonamavu road', 'kochin', 'ernakulam', 'abin123@gmail.com', '9987656785', 'koimmakad house', '683501');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_feedback`
-- 

CREATE TABLE `tbl_feedback` (
  `fb_id` int(50) NOT NULL,
  `ret_name` varchar(50) NOT NULL,
  `fb_desc` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `tbl_feedback`
-- 

INSERT INTO `tbl_feedback` VALUES (0, 'aa', 'its good');
INSERT INTO `tbl_feedback` VALUES (1, 'shafi', 'its good');
INSERT INTO `tbl_feedback` VALUES (2, 'Anil', 'good customer friendly');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_login`
-- 

CREATE TABLE `tbl_login` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL,
  `status` varchar(5) NOT NULL,
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `tbl_login`
-- 

INSERT INTO `tbl_login` VALUES ('aaa@gmail.com', 'Abcd1234', 'staff', '1');
INSERT INTO `tbl_login` VALUES ('admin@gmail.com', 'admin', 'admin', '');
INSERT INTO `tbl_login` VALUES ('anil@gmail.com', 'Anil1234', 'customer', '1');
INSERT INTO `tbl_login` VALUES ('au11@gmail.com', 'Abcd1234', 'staff', '1');
INSERT INTO `tbl_login` VALUES ('au@gmail.com', 'Abcd1234@', 'staff', '1');
INSERT INTO `tbl_login` VALUES ('lee@gmail.com', 'Abcd1234', 'staff', '1');
INSERT INTO `tbl_login` VALUES ('sharon@gmail.com', 'staff', 'staff', '');
INSERT INTO `tbl_login` VALUES ('sweety@gmail.com', 'Sweety123', 'customer', '1');
INSERT INTO `tbl_login` VALUES ('tijo@gmail.com', 'Tijo1234', 'staff', '1');
INSERT INTO `tbl_login` VALUES ('kiranbaby@gmail.co', 'Kiran@123', 'staff', '1');
INSERT INTO `tbl_login` VALUES ('kbbaby256@gmail.com', 'Kiranbaby123@', 'customer', '1');
INSERT INTO `tbl_login` VALUES ('abin123@gmail.com', 'Abin@123', 'customer', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_product`
-- 

CREATE TABLE `tbl_product` (
  `item_id` int(50) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `item_type` varchar(50) NOT NULL,
  `item_img` varchar(50) NOT NULL,
  `item_dtls` varchar(50) NOT NULL,
  `dosage` varchar(50) NOT NULL,
  `amnt` varchar(50) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `vendor_id` varchar(11) NOT NULL,
  PRIMARY KEY  (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `tbl_product`
-- 

INSERT INTO `tbl_product` VALUES (19, 'Oneplus 7T PRO Haze Blue', 'Oneplus', 'mobiles', '../uploads/6qq.jpg', '3120 x 1440 pixels resolution and 516 ppi pixel de', '1', '12000', '16', '');
INSERT INTO `tbl_product` VALUES (17, 'Samsung Galaxy S10 Plus', 'Samsung ', 'mobiles', '../uploads/61s.jpg', '10x hybrid optic zoom, up to 30x super resolution ', '1', '20000', '10', '3');
INSERT INTO `tbl_product` VALUES (18, 'New Apple iPhone 12 ', 'Apple', 'mobiles', '../uploads/phone.jpg', 'Ceramic Shield, tougher than any smartphone glass', '1', '10000', '14', '4');
INSERT INTO `tbl_product` VALUES (14, 'Canon Power Shoot Sx 740', 'Canon', 'camera', '../uploads/a1.jpg', 'senor resolution image sharpness', '1', '50000', '8', '8');
INSERT INTO `tbl_product` VALUES (15, 'Samsung 65Q800T 8K QLED Television 65inch', 'Samsung ', 'tv', '../uploads/tv1.jpg', 'Type: 8K UHD TVResolution: 7680 x 4320HDMI', '1', '10000', '22', '9');
INSERT INTO `tbl_product` VALUES (16, 'Bosch Front Load Washer', '.Bosch', 'washing machine', '../uploads/wachmach2.jpg', 'Type: Front Load Washer', '1', '40000', '19', '10');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_purchase_child`
-- 

CREATE TABLE `tbl_purchase_child` (
  `pur_id` int(11) NOT NULL auto_increment,
  `vendor_id` varchar(50) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  PRIMARY KEY  (`pur_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `tbl_purchase_child`
-- 

INSERT INTO `tbl_purchase_child` VALUES (3, '1', '11', '51', '150');
INSERT INTO `tbl_purchase_child` VALUES (4, '1', '12', '10', '120');
INSERT INTO `tbl_purchase_child` VALUES (5, '6', '15', '21', '210000');
INSERT INTO `tbl_purchase_child` VALUES (6, '6', '15', '31', '310000');
INSERT INTO `tbl_purchase_child` VALUES (7, '8', '14', '10', '500000');
INSERT INTO `tbl_purchase_child` VALUES (8, '9', '15', '10', '100000');
INSERT INTO `tbl_purchase_child` VALUES (9, '10', '16', '32', '40000');
INSERT INTO `tbl_purchase_child` VALUES (10, '10', '16', '32', '40000');
INSERT INTO `tbl_purchase_child` VALUES (11, '9', '15', '24', '240000');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_purchase_master`
-- 

CREATE TABLE `tbl_purchase_master` (
  `pur_id` int(50) NOT NULL,
  `vendor_name` varchar(50) NOT NULL,
  `vendor_cmpny` varchar(50) NOT NULL,
  `v_street` varchar(50) NOT NULL,
  `v_city` varchar(50) NOT NULL,
  `v_district` varchar(50) NOT NULL,
  `vendor_ph` bigint(10) NOT NULL,
  `vendor_email` varchar(50) NOT NULL,
  `pincode` varchar(15) NOT NULL,
  `jdate` date NOT NULL,
  PRIMARY KEY  (`pur_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `tbl_purchase_master`
-- 

INSERT INTO `tbl_purchase_master` VALUES (2, 'siyona', 'Canon', 'varapuzha road', 'kochin', 'ernakulam', 9495690635, 'siyona12@gmail.com', '683517', '2020-11-27');
INSERT INTO `tbl_purchase_master` VALUES (3, 'rugma bose', 'Samsung ', 'koonammavu road', 'kochin', 'ernakulam', 9496447968, 'rugma123@gmail.com', '683517', '2020-11-28');
INSERT INTO `tbl_purchase_master` VALUES (4, 'kiran', 'Apple', 'paravoor road', 'kochi', 'ernakulam', 9020996500, 'syam@gmail.com', '685505', '2020-11-26');
INSERT INTO `tbl_purchase_master` VALUES (5, 'minnu', 'sony', 'edapally road', 'ernakulam', 'kerala', 9445678999, 'minnu123@gmail.com', '683517', '2020-11-27');
INSERT INTO `tbl_purchase_master` VALUES (6, 'siyona', 'Bosch', 'panayikulam road', 'ernakulam', 'kerala', 9495690846, 'siyona@gmail.com', '683415', '2020-11-28');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_staff`
-- 

CREATE TABLE `tbl_staff` (
  `staff_id` int(50) NOT NULL auto_increment,
  `staff_fname` varchar(50) NOT NULL,
  `staff_lname` varchar(50) NOT NULL,
  `staff_dob` varchar(50) NOT NULL,
  `staff_doj` date NOT NULL,
  `staff_street` varchar(50) NOT NULL,
  `staff_city` varchar(50) NOT NULL,
  `staff_district` varchar(50) NOT NULL,
  `staff_gender` varchar(50) NOT NULL,
  `staff_ph` varchar(12) NOT NULL,
  `staff_email` varchar(50) NOT NULL,
  `housename` varchar(50) NOT NULL,
  `pincode` varchar(50) NOT NULL,
  PRIMARY KEY  (`staff_id`),
  UNIQUE KEY `staff_id_3` (`staff_id`),
  UNIQUE KEY `staff_email` (`staff_email`),
  KEY `staff_id` (`staff_id`),
  KEY `staff_id_2` (`staff_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- 
-- Dumping data for table `tbl_staff`
-- 

INSERT INTO `tbl_staff` VALUES (2, 'sharon', 'jerald', '1997-02-04', '2019-08-16', 'panapilly road', 'ernakulam', 'kerala', 'male', '9865432180', 'sharon@gmail.com', 'koimmakad house', '683506');
INSERT INTO `tbl_staff` VALUES (3, 'seetha', 'ram', '12/10/1995', '2020-11-23', 'panapilly road', 'ernakulam', 'kerala', 'female', '9847658745', 'seetha@gmail.com', 'thaliath', '654314');
INSERT INTO `tbl_staff` VALUES (4, 'Tijo', 'Thomas', '04/10/1995', '2020-11-23', 'puthenpally road', 'kochin', 'ernakulam', 'male', '9847658747', 'tijo@gmail.com', 'puthussery house', '683517');
INSERT INTO `tbl_staff` VALUES (5, 'leena', 'kia', '2006-01-02', '2020-11-25', 'Kochin ', 'Kochin ', 'ernakulam', 'female', '9856453449', 'lee@gmail.com', 'Kuthedeth', '546572');
INSERT INTO `tbl_staff` VALUES (6, 'annu', 'john', '1985-01-01', '2020-11-26', 'panapilly road', 'ernakulam', 'kerala', 'female', '9879653459', 'mary123@gmail.com', 'koimmakad house', '683517');
INSERT INTO `tbl_staff` VALUES (7, 'Kiran', 'Baby', '1984-12-07', '2020-11-10', 'varapuzha', 'ernakulam', 'kerala', 'male', '9998887776', 'kiranbaby@gmail.co', 'Puthussery house puthenpally varapuzha', '683517');
